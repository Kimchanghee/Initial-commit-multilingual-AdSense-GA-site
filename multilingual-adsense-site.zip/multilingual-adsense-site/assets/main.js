
// Language detection & apply translations
(function () {
  const params = new URLSearchParams(window.location.search);
  const saved = localStorage.getItem('lang');
  let lang = params.get('lang') || saved || navigator.language || 'en';
  lang = lang.toLowerCase();

  // normalize language codes to our set
  const supported = Object.keys(i18n.map);
  if (!supported.includes(lang)) {
    // try base part e.g., 'en-US' -> 'en'
    const base = lang.split('-')[0];
    lang = supported.includes(base) ? base : 'en';
  }
  i18n.lang = lang;
  i18n.dir = i18n.map[lang]?.dir || 'ltr';
  document.documentElement.lang = lang;
  document.documentElement.dir = i18n.dir;

  // set selector
  const sel = document.getElementById('lang-select');
  if (sel) { sel.value = lang; sel.addEventListener('change', (e)=> {
    const v = e.target.value;
    localStorage.setItem('lang', v);
    const url = new URL(window.location.href);
    url.searchParams.set('lang', v);
    window.location.href = url.toString();
  });}

  // translate static nodes
  document.querySelectorAll('[data-i18n]').forEach(node => {
    const key = node.getAttribute('data-i18n');
    node.textContent = i18n.t(key);
  });

  // render cards
  const cards = document.getElementById('cards');
  const posts = [
    {
      id: 'ai-tools',
      img: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1200&q=60',
      title: {
        en: '10 Free AI Tools That Save Hours',
        ko: '시간을 아껴주는 무료 AI 도구 10',
        ja: '時間節約の無料AIツール10選',
        'zh-CN': '省时的 10 个免费 AI 工具',
        'zh-TW': '省時的 10 個免費 AI 工具',
        es: '10 herramientas de IA gratuitas que ahorran horas',
        fr: '10 outils IA gratuits pour gagner des heures',
        de: '10 kostenlose KI-Tools, die Stunden sparen',
        it: '10 strumenti IA gratuiti che fanno risparmiare ore',
        pt: '10 ferramentas de IA gratuitas para poupar horas',
        ru: '10 бесплатных ИИ-инструментов для экономии времени',
        ar: '10 أدوات ذكاء اصطناعي مجانية توفّر الساعات',
        vi: '10 công cụ AI miễn phí tiết kiệm hàng giờ',
        th: '10 เครื่องมือ AI ฟรีช่วยประหยัดเวลา',
        id: '10 alat AI gratis hemat waktu'
      },
      href: 'articles/article-ai-tools.html'
    },
    {
      id: 'productivity-systems',
      img: 'https://images.unsplash.com/photo-1506784242126-2a0b0b89c56a?auto=format&fit=crop&w=1200&q=60',
      title: {
        en: 'Ultimate Guide to Productivity Systems',
        ko: '생산성 시스템 완전정복',
        ja: '生産性システム完全ガイド',
        'zh-CN': '效率系统终极指南',
        'zh-TW': '生產力系統終極指南',
        es: 'Guía definitiva de sistemas de productividad',
        fr: 'Guide ultime des systèmes de productivité',
        de: 'Ultimativer Guide für Produktivitätssysteme',
        it: 'Guida definitiva ai sistemi di produttività',
        pt: 'Guia definitivo de sistemas de produtividade',
        ru: 'Полное руководство по системам продуктивности',
        ar: 'الدليل النهائي لأنظمة الإنتاجية',
        vi: 'Hướng dẫn tối thượng về hệ thống năng suất',
        th: 'คู่มือระบบเพิ่มผลผลิตขั้นสุด',
        id: 'Panduan lengkap sistem produktivitas'
      },
      href: 'articles/article-productivity.html'
    },
    {
      id: 'automations',
      img: 'https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=1200&q=60',
      title: {
        en: '5 Quick Automations for Busy People',
        ko: '바쁜 사람을 위한 자동화 5가지',
        ja: '忙しい人のための自動化5選',
        'zh-CN': '忙碌人士的 5 个快速自动化',
        'zh-TW': '忙碌人士的 5 個快速自動化',
        es: '5 automatizaciones rápidas para gente ocupada',
        fr: '5 automatisations rapides pour les pressés',
        de: '5 schnelle Automatisierungen für Vielbeschäftigte',
        it: '5 automazioni rapide per i super impegnati',
        pt: '5 automações rápidas para quem vive correndo',
        ru: '5 быстрых автоматизаций для занятых',
        ar: '5 عمليات أتمتة سريعة للمنشغلين',
        vi: '5 tự động hóa nhanh cho người bận rộn',
        th: 'อัตโนมัติ 5 อย่างสำหรับคนยุ่ง',
        id: '5 otomasi cepat untuk orang sibuk'
      },
      href: '#'
    },
    {
      id: 'writing',
      img: 'https://images.unsplash.com/photo-1516239321545-8f3063a04332?auto=format&fit=crop&w=1200&q=60',
      title: {
        en: 'Clear Writing with AI: A Mini Lesson',
        ko: 'AI로 더 쉽게 쓰기: 미니 레슨',
        ja: 'AIで明快な文章を書く：ミニレッスン',
        'zh-CN': '借助 AI 清晰写作：迷你课程',
        'zh-TW': '用 AI 清楚寫作：迷你課程',
        es: 'Escritura clara con IA: mini lección',
        fr: 'Écrire clairement avec l’IA : mini-leçon',
        de: 'Klar schreiben mit KI: Mini-Lektion',
        it: 'Scrivere chiaro con l’IA: mini lezione',
        pt: 'Escrita clara com IA: mini aula',
        ru: 'Ясное письмо с ИИ: мини-урок',
        ar: 'كتابة واضحة بمساعدة الذكاء الاصطناعي: درس قصير',
        vi: 'Viết rõ ràng với AI: bài học ngắn',
        th: 'เขียนให้ชัดด้วย AI: บทเรียนสั้น',
        id: 'Menulis jelas dengan AI: pelajaran mini'
      },
      href: '#'
    }
  ];

  function tFor(lang, obj) {
    return obj[lang] || obj['en'];
  }

  if (cards) {
    for (const p of posts) {
      const card = document.createElement('article');
      card.className = 'card';
      card.innerHTML = `
        <img src="${p.img}" alt="banner">
        <div class="content">
          <h3>${tFor(i18n.lang, p.title)}</h3>
          <p>${i18n.t('hero_tagline')}</p>
          <a class="read" href="${p.href}?lang=${i18n.lang}">${i18n.t('read_more')} →</a>
        </div>
      `;
      cards.appendChild(card);
    }
  }

  // Simple consent gate for GA and ads (non-TCF demo)
  function consentGate(allow) {
    if (allow) {
      if (window.GA_MEASUREMENT_ID && window.GA_MEASUREMENT_ID !== "G-XXXXXXXXXX") {
        gtag('config', window.GA_MEASUREMENT_ID, { 'anonymize_ip': true });
      }
      // Trigger AdSense
      const tryInit = () => {
        try { (adsbygoogle = window.adsbygoogle || []).push({}); } catch(e) { /* ignore */ }
      };
      document.querySelectorAll('.adsbygoogle').forEach(()=> tryInit());
    } else {
      // disable GA
      window['ga-disable-' + window.GA_MEASUREMENT_ID] = true;
    }
  }

  // Cookie banner
  const banner = document.getElementById('cookie-banner');
  const ok = localStorage.getItem('cookie-ok');
  if (!ok) { banner.style.display = 'flex'; }
  document.getElementById('cookie-accept').onclick = () => {
    localStorage.setItem('cookie-ok','1');
    banner.style.display='none';
    consentGate(true);
  };
  document.getElementById('cookie-decline').onclick = () => {
    localStorage.setItem('cookie-ok','0');
    banner.style.display='none';
    consentGate(false);
  };

  if (ok === '1') consentGate(true);
})();
