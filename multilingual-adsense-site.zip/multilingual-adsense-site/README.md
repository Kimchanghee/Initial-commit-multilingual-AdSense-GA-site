
# AI Productivity Hub (Monetizable, 15-language static site)

A lightweight, multilingual static site designed for AdSense monetization and Google Analytics tracking.
Includes a simple cookie consent banner (non-TCF demo).

## 0) Replace IDs
- In `index.html`, `articles/*.html`:
  - Replace **`ca-pub-XXXXXXXXXXXXXXXX`** with your **AdSense publisher ID**.
  - Replace **`G-XXXXXXXXXX`** with your **Google Analytics Measurement ID**.
- In `ads.txt`, replace `pub-XXXXXXXXXXXXXXXX` with your publisher ID.
- In `sitemap.xml` and `robots.txt`, replace `https://example.com` with your actual domain (or GitHub Pages URL).

## 1) Create GitHub repo & push
```bash
REPO_NAME=ai-productivity-hub
git init
git add .
git commit -m "Initial commit: multilingual AdSense+GA site"
git branch -M main
# Create a new repo on GitHub named $REPO_NAME, then:
git remote add origin https://github.com/<YOUR_USERNAME>/$REPO_NAME.git
git push -u origin main
```

## 2) Enable GitHub Pages (via Actions)
- In **Settings → Pages**, set:
  - **Build and deployment → Source:** GitHub Actions
- The included workflow will publish the site automatically on each push to `main`.
- Your site will be available at: `https://<YOUR_USERNAME>.github.io/<REPO_NAME>/`

## 3) GitHub Actions workflow
The workflow at `.github/workflows/pages.yml` uploads the static files and deploys to GitHub Pages.

## 4) Connect AdSense
1. Sign up at https://www.google.com/adsense
2. **Sites → Add site** → enter your GitHub Pages URL.
3. Ensure the AdSense snippet exists (already in `index.html`) and `ads.txt` is live at `/ads.txt`.
4. Wait for **review/approval** (ads won’t show until approved).

## 5) Connect Google Analytics (GA4)
1. Create a GA4 property to get a `G-XXXXXXXXXX` Measurement ID.
2. Replace the placeholder in `index.html` with your ID.
3. Verify data in **Reports → Realtime** after visiting your site (with consent accepted).

## 6) Optional: Custom domain
- For GitHub Pages, add a custom domain in **Settings → Pages → Custom domain** and update DNS (CNAME).
- Update `sitemap.xml` and `robots.txt` to reflect the custom domain.

## 7) EU Consent (Important)
- This repo includes a **simple consent banner** for demo purposes.
- For EU/EEA users, integrate a **TCF v2.2–compliant CMP** to meet AdSense policies in production.

## 8) Add more content
- Edit `assets/i18n.js` to translate additional strings.
- Duplicate `articles/*.html` to add more posts. Link them from `assets/main.js` posts array.

## 9) Local preview
Just open `index.html` in a browser. No build step required.
